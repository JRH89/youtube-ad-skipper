// background.js
// No background processing needed for this extension
